package com.hospital;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/AddPatient")
public class AddPatientServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String name = req.getParameter("name");
        String age = req.getParameter("age");
        String gender = req.getParameter("gender");
        String contact = req.getParameter("contact");

        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            res.sendRedirect("login.jsp");
            return;
        }

        int userId = (int) session.getAttribute("userId");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_db", "root", "Gautam@1234");

            PreparedStatement ps = con.prepareStatement("INSERT INTO patients (name, age, gender, contact, user_id) VALUES (?, ?, ?, ?, ?)");
            ps.setString(1, name);
            ps.setInt(2, Integer.parseInt(age));
            ps.setString(3, gender);
            ps.setString(4, contact);
            ps.setInt(5, userId);

            int i = ps.executeUpdate();
            con.close();

            if (i > 0) {
                req.setAttribute("message", "Patient added successfully!");
            } else {
                req.setAttribute("message", "Failed to add patient.");
            }

            RequestDispatcher rd = req.getRequestDispatcher("add_patient.jsp");
            rd.forward(req, res);

        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("message", "Error: " + e.getMessage());
            RequestDispatcher rd = req.getRequestDispatcher("add_patient.jsp");
            rd.forward(req, res);
        }
    }
}

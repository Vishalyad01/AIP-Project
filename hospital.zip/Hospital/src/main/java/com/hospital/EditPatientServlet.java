package com.hospital;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.*;

@WebServlet("/EditPatient")
public class EditPatientServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        String name = req.getParameter("name");
        int age = Integer.parseInt(req.getParameter("age"));
        String gender = req.getParameter("gender");
        String contact = req.getParameter("contact");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_db", "root", "Gautam@1234");

            PreparedStatement ps = con.prepareStatement("UPDATE patients SET name=?, age=?, gender=?, contact=? WHERE id=?");
            ps.setString(1, name);
            ps.setInt(2, age);
            ps.setString(3, gender);
            ps.setString(4, contact);
            ps.setInt(5, id);

            int i = ps.executeUpdate();

            ps.close();
            con.close();

            if (i > 0) {
                res.sendRedirect("edit_patient.jsp?id=" + id + "&success=1");
            } else {
                res.sendRedirect("edit_patient.jsp?id=" + id + "&success=0");
            }
        } catch (Exception e) {
            e.printStackTrace();
            res.getWriter().println("Error: " + e.getMessage());
        }
    }
}
